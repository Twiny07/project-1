document.addEventListener("DOMContentLoaded", function() {
    var loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        // Simulate authentication (replace this with your actual authentication logic)
        if (username === "twiny_07" && password === "1234") {
            var loggedInUser = { username: username };
            sessionStorage.setItem("loggedInUser", JSON.stringify(loggedInUser));

            window.location.href = "home.html"; // Redirect to the home page
        } else {
            alert("Invalid username or password. Please try again.");
        }
    });
});

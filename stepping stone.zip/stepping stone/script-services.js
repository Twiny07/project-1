var button=document.getElementById("button1");

button.addEventListener("click",function(){
      
    
       window.alert("Your payment has been successful. Thank you!")
    
});
var button=document.getElementById("button2");
button.addEventListener("click",function(){
       window.alert("Your payment has been successful. Thank you!")
});
var button=document.getElementById("button3");
button.addEventListener("click",function(){
       window.alert("Your payment has been successful. Thank you!")
});
var button=document.getElementById("button4");
button.addEventListener("click",function(){
       window.alert("Your payment has been successful. Thank you!")
});
